﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallRun : MonoBehaviour
{
    bool isWallRunning;

    public Transform groundCheck;
    public float wallDistance = 0.4f;
    public Info.tag("WallRunWall") wall;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        isWallRunning = Physics.CheckSphere(groundCheck.position, wallDistance, wall);

        if(isWallRunning == true)
        {
            rb.AddForce(Vector3.up * Time.deltaTime * 10);
        }

    }
}
