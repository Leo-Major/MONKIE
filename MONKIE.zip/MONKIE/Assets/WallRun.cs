﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallRun : MonoBehaviour
{
    bool isWallRunning;
    public CharacterController controller;
    public Transform groundCheck;
    public float wallDistance = 0.4f;
    public LayerMask wallmask;
    public float wallupforce = 10f;
    Vector3 velocity;
    

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        isWallRunning = Physics.CheckSphere(groundCheck.position, wallDistance, wallmask);

        if (isWallRunning == true)
        {
            velocity.y = +20f;
            Debug.Log("Running");
        }

    }
}

